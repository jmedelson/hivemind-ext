const AWS = require('aws-sdk');
const documentClient = new AWS.DynamoDB.DocumentClient({ region: 'us-east-2' });
const jwt = require('jsonwebtoken');
const axios = require('axios');

const mainHandler = async(flag, event) =>{
    if(flag=="scene"){
        let payload = event['body']['payload'];
        console.log("PAYLOAD:", payload);
        return(payload)
    }
}

exports.handler = async (event) => {
    const headers = {
        // ['Access-Control-Allow-Origin']: event.headers.origin,
        ['Access-Control-Allow-Origin']: '*',
        ["Access-Control-Allow-Credentials"] : true,
        ['Access-Control-Allow-Methods']: "PUT, GET, POST, DELETE, OPTIONS",
        ["Access-Control-Allow-Headers"]:  "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
    };
    if(event['httpMethod'] == 'OPTIONS'){
        return { statusCode:200, body: "sucess", headers };
    }
    console.log("EVENT",event['body'])
    let ret = await mainHandler(event['body']['flag'], event)
    // console.log("EVENT: ", event['pathParameters'], "LENGTH:", event['pathParameters'].length>0)
    // TODO implement
    
    var x = {
        data:{
            id:"loaded from AWS",
            message:"HELLO WORLD"
        }
    }
    var body= JSON.stringify(x)
    var statusCode = 200
    return { statusCode, body: JSON.stringify(body, null, 2), headers };
};
